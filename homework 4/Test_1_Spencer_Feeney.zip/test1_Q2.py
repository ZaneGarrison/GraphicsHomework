#/usr/bin/python3
__author__ = "Spencer Feeney"
import MySQLdb

# user input section.
userID = input('id: ')
password = input('Password: ')

#build the database connection
db = MySQLdb.connect("localhost",userID,password,'courses')
try:
    #making the cursor
    cursor = db.cursor()
    #excute the query
    cursor.execute("select * from grade where score>90")
    #fetch all results so we can just hard print it.
    result = cursor.fetchall()
    print(result)
except Exception as E:
    # I like using Exception as E so I can get the full detail list of the error.
    print('ERROR')# print error message
    print(str(E))# print what the error was.

# close the db connection either way since the connection is open either way.
db.close()